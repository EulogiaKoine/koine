"use strict"
module.exports = function(_Array){
    _Array.extension.init()
}