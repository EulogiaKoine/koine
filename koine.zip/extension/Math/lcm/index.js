"use strict"

module.exports = (function(){

const gcd = require('../gcd')

/**
 * @name Math.lcm
 * @param {...number} n
 * @returns {number} least common multiple of numbers
 * @pre isInteger(...n) == true && ...n > 0
 */
function lcm(){
    const d = gcd.apply(this, arguments)
    let r = 1
    for(let i = 0; i < arguments.length; i++)
        r *= arguments[i]
    return r / d
}

return lcm
})()