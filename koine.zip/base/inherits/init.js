"use strict"
module.exports = (inherits, _global) => {
    _global.inherits = inherits
}