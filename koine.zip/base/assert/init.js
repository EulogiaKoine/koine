"use strict"

module.exports = (assert, _global) => {
    _global.assert = assert
}