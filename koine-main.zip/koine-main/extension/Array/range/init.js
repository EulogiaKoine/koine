"use strict"
module.exports = function(range){
    if(!Array.range)
        Array.range = range
}