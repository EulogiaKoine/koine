"use strict"
module.exports = function(clamp){
    if(!Math.clamp)
        Math.clamp = clamp
}